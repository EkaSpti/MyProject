package com.pab.zenith.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.pab.zenith.R
import com.pab.zenith.data.Mountain
import com.pab.zenith.data.MountainsRepository

class AdminEditFragment : Fragment() {

    private lateinit var etMountainName: EditText
    private lateinit var etLocation: EditText
    private lateinit var etHeight: EditText
    private lateinit var etRating: EditText
    private lateinit var etImageUrl: EditText
    private lateinit var etDescription: EditText
    private lateinit var chipGroupDifficulty: ChipGroup
    private lateinit var tvError: TextView
    private lateinit var tvSuccess: TextView
    private lateinit var btnSave: MaterialButton

    private lateinit var mountain: Mountain

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_admin_edit, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViews(view)
        loadMountain()
        setupListener()
    }

    private fun initViews(view: View) {
        etMountainName = view.findViewById(R.id.etMountainName)
        etLocation = view.findViewById(R.id.etLocation)
        etHeight = view.findViewById(R.id.etHeight)
        etRating = view.findViewById(R.id.etRating)
        etImageUrl = view.findViewById(R.id.etImageUrl)
        etDescription = view.findViewById(R.id.etDescription)
        chipGroupDifficulty = view.findViewById(R.id.chipGroupDifficulty)
        tvError = view.findViewById(R.id.tvError)
        tvSuccess = view.findViewById(R.id.tvSuccess)
        btnSave = view.findViewById(R.id.btnSaveMountain)
    }

    private fun loadMountain() {
        val args = AdminEditFragmentArgs.fromBundle(requireArguments())
        val mountainId = args.mountainId

        mountain = MountainsRepository.getMountainById(mountainId)
            ?: run {
                findNavController().popBackStack()
                return
            }

        // Set data ke form
        etMountainName.setText(mountain.name)
        etLocation.setText(mountain.location)
        etHeight.setText(mountain.height)
        etRating.setText(mountain.rating.toString())
        etImageUrl.setText(mountain.image)
        etDescription.setText(mountain.description)

        when (mountain.difficulty) {
            Mountain.Difficulty.MUDAH -> chipGroupDifficulty.check(R.id.chipMudah)
            Mountain.Difficulty.SEDANG -> chipGroupDifficulty.check(R.id.chipSedang)
            Mountain.Difficulty.SULIT -> chipGroupDifficulty.check(R.id.chipSulit)
        }
    }

    private fun setupListener() {
        btnSave.setOnClickListener {
            saveChanges()
        }
    }

    private fun saveChanges() {
        tvError.visibility = View.GONE
        tvSuccess.visibility = View.GONE

        val name = etMountainName.text.toString().trim()
        val location = etLocation.text.toString().trim()
        val height = etHeight.text.toString().trim()
        val ratingText = etRating.text.toString().trim()
        val imageUrl = etImageUrl.text.toString().trim()
        val description = etDescription.text.toString().trim()

        if (name.isEmpty() || location.isEmpty() || height.isEmpty() ||
            ratingText.isEmpty() || imageUrl.isEmpty() || description.isEmpty()
        ) {
            showError("Semua field wajib diisi")
            return
        }

        val rating = ratingText.toDoubleOrNull()
        if (rating == null || rating !in 1.0..5.0) {
            showError("Rating harus 1.0 - 5.0")
            return
        }

        val difficulty = when (chipGroupDifficulty.checkedChipId) {
            R.id.chipSedang -> Mountain.Difficulty.SEDANG
            R.id.chipSulit -> Mountain.Difficulty.SULIT
            else -> Mountain.Difficulty.MUDAH
        }

        val updatedMountain = mountain.copy(
            name = name,
            location = location,
            height = height,
            rating = rating,
            image = imageUrl,
            description = description,
            difficulty = difficulty,
            images = listOf(imageUrl)
        )

        MountainsRepository.updateMountain(mountain.id, updatedMountain)

        showSuccess("Data gunung berhasil diperbarui")
    }

    private fun showError(msg: String) {
        tvError.text = msg
        tvError.visibility = View.VISIBLE
    }

    private fun showSuccess(msg: String) {
        tvSuccess.text = msg
        tvSuccess.visibility = View.VISIBLE
    }

    companion object {
        fun newInstance(mountainId: String): AdminEditFragment {
            val fragment = AdminEditFragment()
            val bundle = Bundle()
            bundle.putString("mountainId", mountainId)
            fragment.arguments = bundle
            return fragment
        }
    }
}
