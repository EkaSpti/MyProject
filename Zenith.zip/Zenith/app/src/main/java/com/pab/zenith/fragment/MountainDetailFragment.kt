package com.pab.zenith.fragment

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.pab.zenith.R
import com.pab.zenith.adapter.GalleryAdapter
import com.pab.zenith.data.MountainsRepository
import com.pab.zenith.databinding.FragmentMountainDetailBinding
import com.pab.zenith.adapter.ReviewAdapter
import androidx.navigation.fragment.findNavController






class MountainDetailFragment : Fragment(R.layout.fragment_mountain_detail) {

    private var _binding: FragmentMountainDetailBinding? = null
    private val binding get() = _binding!!

    private val args: MountainDetailFragmentArgs by navArgs()




    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentMountainDetailBinding.bind(view)

        val mountain = MountainsRepository.getMountainById(args.mountainId)

        mountain?.let { data ->
            binding.apply {

                // ===== BASIC INFO =====
                tvNameDetail.text = data.name
                tvLocationDetail.text = data.location
                tvDescriptionDetail.text = data.description
                tvHeightDetail.text = data.height
                tvRatingValue.text = data.rating.toString()
                ratingBar.rating = data.rating.toFloat()

                tvDifficultyDetail.text =
                    data.difficulty.name.lowercase()
                        .replaceFirstChar { it.uppercase() }

                Glide.with(requireContext())
                    .load(data.image)
                    .placeholder(R.drawable.mountain_placeholder)
                    .into(ivMountainDetail)

                btnAddReview.setOnClickListener {
                    val action =
                        MountainDetailFragmentDirections
                            .actionDetailToAddReview(args.mountainId)

                    findNavController().navigate(action)
                }

                // ===== GALLERY =====
                rvGallery.apply {
                    layoutManager = LinearLayoutManager(
                        requireContext(),
                        LinearLayoutManager.HORIZONTAL,
                        false
                    )
                    adapter = GalleryAdapter(data.images)
                }

                // ===== REVIEWS =====
                if (data.reviews.isEmpty()) {
                    tvNoReview.visibility = View.VISIBLE
                    rvReviews.visibility = View.GONE
                } else {
                    tvNoReview.visibility = View.GONE
                    rvReviews.visibility = View.VISIBLE

                    rvReviews.layoutManager =
                        LinearLayoutManager(requireContext())
                    rvReviews.adapter =
                        ReviewAdapter(data.reviews)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
