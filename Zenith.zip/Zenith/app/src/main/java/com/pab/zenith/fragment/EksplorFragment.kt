package com.pab.zenith.fragment

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pab.zenith.R
import com.pab.zenith.adapter.MountainAdapter
import com.pab.zenith.data.Mountain
import com.pab.zenith.data.MountainsRepository
import com.pab.zenith.data.UserSession
import com.google.android.material.chip.ChipGroup

class EksplorFragment : Fragment() {

    private lateinit var mountains: List<Mountain>
    private lateinit var filteredMountains: List<Mountain>
    private lateinit var adapter: MountainAdapter

    private lateinit var etSearch: EditText
    private lateinit var chipGroupDifficulty: ChipGroup
    private lateinit var tvResultsCount: TextView
    private lateinit var rvMountains: RecyclerView
    private lateinit var layoutEmptyState: LinearLayout

    private var selectedDifficulty: Mountain.Difficulty? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_eksplor, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViews(view)
        loadData()
        setupSearch()
        setupFilters()
        setupRecyclerView()
        filterMountains()
    }

    private fun initViews(view: View) {
        etSearch = view.findViewById(R.id.etSearch)
        chipGroupDifficulty = view.findViewById(R.id.chipGroupDifficulty)
        tvResultsCount = view.findViewById(R.id.tvResultsCount)
        rvMountains = view.findViewById(R.id.rvMountains)
        layoutEmptyState = view.findViewById(R.id.layoutEmptyState)
    }

    private fun loadData() {
        mountains = MountainsRepository.getMountains()
        filteredMountains = mountains
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterMountains()
            }
        })
    }

    private fun setupFilters() {
        chipGroupDifficulty.setOnCheckedStateChangeListener { _, checkedIds ->
            selectedDifficulty = when (checkedIds.firstOrNull()) {
                R.id.chipEasy -> Mountain.Difficulty.MUDAH
                R.id.chipMedium -> Mountain.Difficulty.SEDANG
                R.id.chipHard -> Mountain.Difficulty.SULIT
                else -> null
            }
            filterMountains()
        }
    }

    private fun setupRecyclerView() {
        // 1. Inisialisasi adapter dengan Safe Args
        adapter = MountainAdapter(
            mountains = filteredMountains,
            layoutType = MountainAdapter.LayoutType.VERTICAL,
            onItemClick = { mountain ->

                val action = EksplorFragmentDirections
                    .actionEksplorFragmentToMountainDetailFragment(mountain.id)
                findNavController().navigate(action)
            },
            onFavoriteClick = { mountain ->
                UserSession.toggleFavorite(mountain.id)
                adapter.notifyItemChanged(filteredMountains.indexOf(mountain))
            }
        )

        // 2. Set ke RecyclerView
        rvMountains.apply {
            layoutManager = GridLayoutManager(context, 2)
            adapter = this@EksplorFragment.adapter
        }


    }



    private fun filterMountains() {
        val query = etSearch.text.toString().lowercase()

        filteredMountains = mountains.filter { mountain ->
            val matchesSearch = mountain.name.lowercase().contains(query) ||
                    mountain.location.lowercase().contains(query)
            val matchesDifficulty = selectedDifficulty == null || mountain.difficulty == selectedDifficulty
            matchesSearch && matchesDifficulty
        }

        adapter.updateData(filteredMountains)
        tvResultsCount.text = getString(R.string.eksplor_found_format, filteredMountains.size)

        if (filteredMountains.isEmpty()) {
            rvMountains.visibility = View.GONE
            layoutEmptyState.visibility = View.VISIBLE
        } else {
            rvMountains.visibility = View.VISIBLE
            layoutEmptyState.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        adapter.notifyDataSetChanged()
    }



}