package com.pab.zenith.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.pab.zenith.R
import com.pab.zenith.data.Mountain
import com.pab.zenith.data.UserSession



class MountainAdapter(
    private var mountains: List<Mountain>,
    private val layoutType: LayoutType = LayoutType.VERTICAL,
    private val isAdmin: Boolean = false,
    private val onItemClick: (Mountain) -> Unit = {},
    private val onFavoriteClick: (Mountain) -> Unit = {},
    private val onDeleteClick: (Mountain) -> Unit = {}

) : RecyclerView.Adapter<MountainAdapter.MountainViewHolder>() {

    enum class LayoutType {
        HORIZONTAL, VERTICAL
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MountainViewHolder {
        val layoutId = when (layoutType) {
            LayoutType.HORIZONTAL -> R.layout.item_mountain_horizontal
            LayoutType.VERTICAL -> R.layout.item_mountain_vertical
        }
        val view = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        return MountainViewHolder(view)
    }

    override fun onBindViewHolder(holder: MountainViewHolder, position: Int) {
        holder.bind(mountains[position])
    }

    override fun getItemCount(): Int = mountains.size

    fun updateData(newMountains: List<Mountain>) {
        mountains = newMountains
        notifyDataSetChanged()
    }

    inner class MountainViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val ivMountainImage: ImageView = itemView.findViewById(R.id.ivMountainImage)
        private val tvMountainName: TextView = itemView.findViewById(R.id.tvMountainName)
        private val tvMountainLocation: TextView = itemView.findViewById(R.id.tvMountainLocation)
        private val tvMountainRating: TextView = itemView.findViewById(R.id.tvMountainRating)
        private val btnFavorite: FrameLayout = itemView.findViewById(R.id.btnFavorite)
        private val ivFavorite: ImageView = itemView.findViewById(R.id.ivFavorite)


        fun bind(mountain: Mountain) {

            Glide.with(itemView.context)
                .load(mountain.image)
                .centerCrop()
                .placeholder(R.drawable.mountain_placeholder)
                .into(ivMountainImage)

            tvMountainName.text = mountain.name
            tvMountainLocation.text = mountain.location
            tvMountainRating.text = String.format("%.1f", mountain.rating)

            // ===== MODE ADMIN =====
            if (isAdmin) {
                btnFavorite.visibility = View.VISIBLE
                ivFavorite.setImageResource(R.drawable.ic_delete)
                btnFavorite.setOnClickListener {
                    onDeleteClick(mountain) // DELETE
                }

                // ===== KLIK ITEM =====
                itemView.setOnClickListener {
                    onItemClick(mountain)
                }

            }




            // ===== MODE USER =====
            else {
                updateFavoriteIcon(mountain.id)
                btnFavorite.setOnClickListener {
                    onFavoriteClick(mountain)
                    updateFavoriteIcon(mountain.id)
                }
            }

            // ===== KLIK ITEM =====
            itemView.setOnClickListener {
                onItemClick(mountain)
            }
        }

        private fun updateFavoriteIcon(mountainId: String) {
            if (UserSession.isFavorite(mountainId)) {
                ivFavorite.setImageResource(R.drawable.ic_favorite_filled)
            } else {
                ivFavorite.setImageResource(R.drawable.ic_favorite_border)
            }
        }
    }
}

