package com.pab.zenith

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.pab.zenith.data.UserSession
import com.google.android.material.button.MaterialButton

class RegisterActivity : AppCompatActivity() {

    private lateinit var ivBack: ImageView
    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var ivTogglePassword: ImageView
    private lateinit var ivToggleConfirmPassword: ImageView
    private lateinit var btnRegister: MaterialButton
    private lateinit var tvLogin: TextView
    private lateinit var tvError: TextView

    private var isPasswordVisible = false
    private var isConfirmPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        initViews()
        setupListeners()
    }

    private fun initViews() {
        ivBack = findViewById(R.id.ivBack)
        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        ivTogglePassword = findViewById(R.id.ivTogglePassword)
        ivToggleConfirmPassword = findViewById(R.id.ivToggleConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
        tvLogin = findViewById(R.id.tvLogin)
        tvError = findViewById(R.id.tvError)
    }

    private fun setupListeners() {
        ivBack.setOnClickListener {
            finish()
        }

        ivTogglePassword.setOnClickListener {
            togglePasswordVisibility(etPassword, ivTogglePassword, isPasswordVisible) {
                isPasswordVisible = it
            }
        }

        ivToggleConfirmPassword.setOnClickListener {
            togglePasswordVisibility(etConfirmPassword, ivToggleConfirmPassword, isConfirmPasswordVisible) {
                isConfirmPasswordVisible = it
            }
        }

        btnRegister.setOnClickListener {
            handleRegister()
        }

        tvLogin.setOnClickListener {
            finish()
        }
    }

    private fun togglePasswordVisibility(editText: EditText, imageView: ImageView, currentState: Boolean, updateState: (Boolean) -> Unit) {
        val newState = !currentState
        if (newState) {
            editText.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            imageView.setImageResource(R.drawable.ic_eye)
        } else {
            editText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            imageView.setImageResource(R.drawable.ic_eye)
        }
        editText.setSelection(editText.text.length)
        updateState(newState)
    }

    private fun handleRegister() {
        val name = etName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()
        val confirmPassword = etConfirmPassword.text.toString()

        tvError.visibility = View.GONE

        when {
            name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() -> {
                showError("Semua field harus diisi")
            }
            !email.contains("@") -> {
                showError("Format email tidak valid")
            }
            password.length < 6 -> {
                showError("Password minimal 6 karakter")
            }
            password != confirmPassword -> {
                showError("Password tidak cocok")
            }
            email.lowercase() == "admin@zenith.com" -> {
                showError("Email ini sudah terdaftar sebagai admin")
            }
            else -> {
                val user = UserSession.register(name, email, password)
                if (user != null) {
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    showError("Registrasi gagal")
                }
            }
        }
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = View.VISIBLE
    }
}
