package com.pab.zenith.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.pab.zenith.R
import com.pab.zenith.adapter.MountainAdapter
import com.pab.zenith.data.Mountain
import com.pab.zenith.data.MountainsRepository
import com.pab.zenith.data.UserSession
import com.google.android.material.button.MaterialButton
import androidx.navigation.fragment.findNavController


class BerandaFragment : Fragment() {

    private lateinit var mountains: List<Mountain>
    private lateinit var recommendationsAdapter: MountainAdapter
    private lateinit var popularAdapter: MountainAdapter

    // Featured views
    private lateinit var ivFeaturedImage: ImageView
    private lateinit var tvFeaturedName: TextView
    private lateinit var tvFeaturedLocation: TextView
    private lateinit var tvFeaturedDescription: TextView
    private lateinit var tvFeaturedHeight: TextView
    private lateinit var tvFeaturedRating: TextView
    private lateinit var btnFeaturedDetail: MaterialButton

    // RecyclerViews
    private lateinit var rvRecommendations: RecyclerView
    private lateinit var rvPopular: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_beranda, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        initViews(view)
        loadData()
        setupFeaturedMountain()
        setupRecyclerViews()
    }

    private fun initViews(view: View) {
        // Featured views
        ivFeaturedImage = view.findViewById(R.id.ivFeaturedImage)
        tvFeaturedName = view.findViewById(R.id.tvFeaturedName)
        tvFeaturedLocation = view.findViewById(R.id.tvFeaturedLocation)
        tvFeaturedDescription = view.findViewById(R.id.tvFeaturedDescription)
        tvFeaturedHeight = view.findViewById(R.id.tvFeaturedHeight)
        tvFeaturedRating = view.findViewById(R.id.tvFeaturedRating)
        btnFeaturedDetail = view.findViewById(R.id.btnFeaturedDetail)

        // RecyclerViews
        rvRecommendations = view.findViewById(R.id.rvRecommendations)
        rvPopular = view.findViewById(R.id.rvPopular)
    }

    private fun loadData() {
        mountains = MountainsRepository.getMountains().sortedByDescending { it.rating }
    }

    private fun setupFeaturedMountain() {
        val featured = mountains.firstOrNull() ?: return

        Glide.with(this)
            .load(featured.image)
            .centerCrop()
            .into(ivFeaturedImage)

        tvFeaturedName.text = featured.name
        tvFeaturedLocation.text = featured.location
        tvFeaturedDescription.text = featured.description
        tvFeaturedHeight.text = featured.height
        tvFeaturedRating.text = String.format("%.1f", featured.rating)

        btnFeaturedDetail.setOnClickListener {
            val action =
                BerandaFragmentDirections
                    .actionBerandaFragmentToMountainDetailFragment(featured.id)
            findNavController().navigate(action)
        }
    }

    private fun setupRecyclerViews() {
        // Recommendations (Horizontal)
        recommendationsAdapter = MountainAdapter(
            mountains.drop(1).take(3),
            MountainAdapter.LayoutType.HORIZONTAL,
            onItemClick = { mountain ->

                val action =
                    BerandaFragmentDirections
                        .actionBerandaFragmentToMountainDetailFragment(mountain.id)
                findNavController().navigate(action)


            },

            onFavoriteClick = { mountain ->
                UserSession.toggleFavorite(mountain.id)
                recommendationsAdapter.notifyDataSetChanged()
            }
        )

        rvRecommendations.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
            adapter = recommendationsAdapter
        }

        // Popular (Grid)
        popularAdapter = MountainAdapter(
            mountains.take(4),
            MountainAdapter.LayoutType.VERTICAL,
            onItemClick = { mountain ->
                val action =
                    BerandaFragmentDirections
                        .actionBerandaFragmentToMountainDetailFragment(mountain.id)
                findNavController().navigate(action)
            },
            onFavoriteClick = { mountain ->
                UserSession.toggleFavorite(mountain.id)
                popularAdapter.notifyDataSetChanged()
            }
        )


        rvPopular.apply {
            layoutManager = GridLayoutManager(context, 2)
            adapter = popularAdapter
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh adapters in case favorites changed
        recommendationsAdapter.notifyDataSetChanged()
        popularAdapter.notifyDataSetChanged()
    }
}