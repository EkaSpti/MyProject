package com.pab.zenith.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pab.zenith.R
import com.pab.zenith.adapter.MountainAdapter
import com.pab.zenith.data.MountainsRepository
import android.content.Intent
import com.pab.zenith.AdminEditActivity

class AdminManageFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MountainAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_admin_manage, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        recyclerView = view.findViewById(R.id.rvMountains)


        setupRecyclerView()

    }

    override fun onResume() {
        super.onResume()
        adapter.updateData(MountainsRepository.getMountains())
    }

    private fun setupRecyclerView() {
        adapter = MountainAdapter(
            mountains = MountainsRepository.getMountains(),
            isAdmin = true,

            onItemClick = { mountain ->
                val intent = Intent(requireContext(), AdminEditActivity::class.java)
                intent.putExtra("mountainId", mountain.id)
                startActivity(intent)
            },

            // 👉 DELETE
            onDeleteClick = { mountain ->
                showDeleteDialog(mountain)
            }
        )

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter
    }

    private fun openEditFragment(mountainId: String) {
        val fragment = AdminEditFragment.newInstance(mountainId)

        requireActivity().supportFragmentManager
            .beginTransaction()
            .replace(R.id.viewPager, fragment)
            .addToBackStack(null)
            .commit()
    }


    private fun showDeleteDialog(mountain: com.pab.zenith.data.Mountain) {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Data")
            .setMessage("Yakin ingin menghapus ${mountain.name}?")
            .setPositiveButton("Hapus") { _, _ ->
                MountainsRepository.deleteMountain(mountain.id)
                adapter.updateData(MountainsRepository.getMountains())
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
