package com.pab.zenith.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import com.pab.zenith.MainActivity
import com.pab.zenith.R
import com.pab.zenith.data.UserSession
import androidx.navigation.fragment.findNavController


class ProfilFragment : Fragment() {

    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var layoutAdminBadge: LinearLayout
    private lateinit var cvAdminMenu: CardView
    private lateinit var cvSettings: CardView
    private lateinit var cvLogout: CardView
    private lateinit var tvStatsFavorites: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profil, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViews(view)
        loadUserData()
        setupListeners()
    }

    private fun initViews(view: View) {
        tvUserName = view.findViewById(R.id.tvUserName)
        tvUserEmail = view.findViewById(R.id.tvUserEmail)
        layoutAdminBadge = view.findViewById(R.id.layoutAdminBadge)
        cvAdminMenu = view.findViewById(R.id.cvAdminMenu)
        cvSettings = view.findViewById(R.id.cvSettings)
        cvLogout = view.findViewById(R.id.cvLogout)
        tvStatsFavorites = view.findViewById(R.id.tvStatsFavorites)
    }

    private fun loadUserData() {
        val user = UserSession.getCurrentUser() ?: return

        tvUserName.text = user.name
        tvUserEmail.text = user.email

        // Show/hide admin elements
        if (user.isAdmin) {
            layoutAdminBadge.visibility = View.VISIBLE
            cvAdminMenu.visibility = View.VISIBLE
        } else {
            layoutAdminBadge.visibility = View.GONE
            cvAdminMenu.visibility = View.GONE
        }

        // Update favorites count
        tvStatsFavorites.text = UserSession.getFavorites().size.toString()
    }

    private fun setupListeners() {
        cvAdminMenu.setOnClickListener {
            (activity as? MainActivity)?.navigateToAdmin()
        }

        cvSettings.setOnClickListener {
            findNavController().navigate(R.id.editProfileFragment)
        }


        cvLogout.setOnClickListener {
            (activity as? MainActivity)?.logout()
        }
    }

    override fun onResume() {
        super.onResume()
        loadUserData()
    }
}
