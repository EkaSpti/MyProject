package com.pab.zenith.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.pab.zenith.R
import com.pab.zenith.data.MountainsRepository
import com.pab.zenith.data.UserSession

class AdminOverviewFragment : Fragment() {

    private lateinit var tvTotalMountains: TextView
    private lateinit var tvTotalFavorites: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_admin_overview, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tvTotalMountains = view.findViewById(R.id.tvTotalMountains)
        tvTotalFavorites = view.findViewById(R.id.tvTotalFavorites)

        val totalMountains = MountainsRepository.getMountains().size
        val totalFavorites = UserSession.getFavorites().size

        tvTotalMountains.text = totalMountains.toString()
        tvTotalFavorites.text = totalFavorites.toString()
    }
}
