package com.pab.zenith.data

data class Review(
    val userName: String,
    val rating: Float,
    val comment: String
)
