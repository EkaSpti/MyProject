package com.pab.zenith.fragment

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.pab.zenith.R
import com.pab.zenith.data.MountainsRepository
import com.pab.zenith.data.Review

class AddReviewFragment : Fragment(R.layout.fragment_add_review) {

    private val args: AddReviewFragmentArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etName = view.findViewById<EditText>(R.id.etUserName)
        val etComment = view.findViewById<EditText>(R.id.etComment)
        val ratingBar = view.findViewById<RatingBar>(R.id.ratingBarReview)
        val btnSubmit = view.findViewById<Button>(R.id.btnSubmitReview)

        btnSubmit.setOnClickListener {
            val review = Review(
                userName = etName.text.toString(),
                rating = ratingBar.rating,
                comment = etComment.text.toString()
            )

            val mountain =
                MountainsRepository.getMountainById(args.mountainId)

            mountain?.reviews?.add(review)

            findNavController().navigateUp()
        }
    }
}
