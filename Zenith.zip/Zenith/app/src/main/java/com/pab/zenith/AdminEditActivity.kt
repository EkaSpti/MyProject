package com.pab.zenith

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.pab.zenith.fragment.AdminEditFragment

class AdminEditActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_edit)

        if (savedInstanceState == null) {
            val fragment = AdminEditFragment().apply {
                arguments = Bundle().apply {
                    putString("mountainId", intent.getStringExtra("mountainId"))
                }
            }

            supportFragmentManager.beginTransaction()
                .replace(R.id.adminEditContainer, fragment)
                .commit()
        }
    }
}
