package com.pab.zenith.data

data class Mountain(
    val id: String,
    val name: String,
    val image: String,
    val images: List<String>,
    val rating: Double,
    val location: String,
    val height: String,
    val description: String,
    val difficulty: Difficulty,
    val reviews: MutableList<Review> = mutableListOf()

) {
    enum class Difficulty {
        MUDAH, SEDANG, SULIT
    }
}

object MountainsRepository {
    private val mountains = mutableListOf<Mountain>()

    init {
        mountains.addAll(getDefaultMountains())
    }

    fun getMountains(): List<Mountain> = mountains.toList()
    
    fun addMountain(mountain: Mountain) {
        mountains.add(mountain)
    }

    fun updateMountain(mountainId: String, updatedMountain: Mountain) {
        val index = mountains.indexOfFirst { it.id == mountainId }
        if (index != -1) {
            mountains[index] = updatedMountain
        }
    }

    fun deleteMountain(mountainId: String) {
        mountains.removeAll { it.id == mountainId }
    }

    fun getMountainById(mountainId: String): Mountain? {
        return mountains.find { it.id == mountainId }
    }

    private fun getDefaultMountains(): List<Mountain> = listOf(
        Mountain(
            id = "1",
            name = "Gunung Bromo",
            image = "https://images.unsplash.com/photo-1679109426640-966f09b70c88",
            rating = 4.8,
            location = "Jawa Timur",
            height = "2.329 mdpl",
            description = "Gunung Bromo adalah salah satu gunung berapi yang paling terkenal di Indonesia. Terletak di Taman Nasional Bromo Tengger Semeru, gunung ini menawarkan pemandangan matahari terbit yang spektakuler.",
            difficulty = Mountain.Difficulty.MUDAH,
            images = listOf(
                "https://images.unsplash.com/photo-1",
                "https://images.unsplash.com/photo-2",
                "https://images.unsplash.com/photo-3"
            )
        ),
        Mountain(
            id = "2",
            name = "Gunung Rinjani",
            image = "https://images.unsplash.com/photo-1707478508419-437bd96166b1",
            rating = 4.9,
            location = "Nusa Tenggara Barat",
            height = "3.726 mdpl",
            description = "Gunung Rinjani adalah gunung berapi tertinggi kedua di Indonesia. Danau Segara Anak di kawahnya menjadi daya tarik utama bagi para pendaki.",
            difficulty = Mountain.Difficulty.SULIT,
            images = listOf(
                "https://images.unsplash.com/photo-1",
                "https://images.unsplash.com/photo-2",
                "https://images.unsplash.com/photo-3"
            )

        ),
        Mountain(
            id = "3",
            name = "Gunung Semeru",
            image = "https://images.unsplash.com/photo-1541526473962-db2b2baca7c6",
            rating = 4.7,
            location = "Jawa Timur",
            height = "3.676 mdpl",
            description = "Gunung Semeru atau Mahameru adalah gunung tertinggi di Pulau Jawa. Puncaknya yang sering mengeluarkan asap menjadi pemandangan ikonik.",
            difficulty = Mountain.Difficulty.SULIT,
            images = listOf(
                "https://images.unsplash.com/photo-1",
                "https://images.unsplash.com/photo-2",
                "https://images.unsplash.com/photo-3"
            )
        ),
        Mountain(
            id = "4",
            name = "Gunung Merbabu",
            image = "https://images.unsplash.com/photo-1651890044335-a55d59f5b167",
            rating = 4.6,
            location = "Jawa Tengah",
            height = "3.145 mdpl",
            description = "Gunung Merbabu menawarkan pemandangan sunrise yang indah dengan sabana luas di puncaknya. Jalur pendakian cukup menantang namun pemandangannya sangat memuaskan.",
            difficulty = Mountain.Difficulty.SEDANG,
            images = listOf(
                "https://images.unsplash.com/photo-1",
                "https://images.unsplash.com/photo-2",
                "https://images.unsplash.com/photo-3"
            )
        ),
        Mountain(
            id = "5",
            name = "Gunung Kerinci",
            image = "https://images.unsplash.com/photo-1616584748451-41bbf17a4069",
            rating = 4.8,
            location = "Jambi",
            height = "3.805 mdpl",
            description = "Gunung Kerinci adalah gunung tertinggi di Sumatera dan gunung berapi tertinggi di Indonesia. Berada di Taman Nasional Kerinci Seblat.",
            difficulty = Mountain.Difficulty.SULIT,
            images = listOf(
                "https://images.unsplash.com/photo-1",
                "https://images.unsplash.com/photo-2",
                "https://images.unsplash.com/photo-3"
            )
        ),
        Mountain(
            id = "6",
            name = "Gunung Merapi",
            image = "https://images.unsplash.com/photo-1671390989624-49bc7308dc95",
            rating = 4.5,
            location = "Jawa Tengah & DI Yogyakarta",
            height = "2.930 mdpl",
            description = "Gunung Merapi adalah salah satu gunung berapi paling aktif di Indonesia. Meskipun berbahaya, pemandangan dan keindahan alamnya sangat menarik.",
            difficulty = Mountain.Difficulty.SEDANG,
            images = listOf(
                "https://images.unsplash.com/photo-1",
                "https://images.unsplash.com/photo-2",
                "https://images.unsplash.com/photo-3"
            )
        )
    )
}