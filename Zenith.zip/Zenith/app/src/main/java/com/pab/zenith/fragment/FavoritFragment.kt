package com.pab.zenith.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pab.zenith.R
import com.pab.zenith.adapter.MountainAdapter
import com.pab.zenith.data.MountainsRepository
import com.pab.zenith.data.UserSession
import androidx.navigation.fragment.findNavController




class FavoritFragment : Fragment() {

    private lateinit var tvFavoriteCount: TextView
    private lateinit var rvFavorites: RecyclerView
    private lateinit var layoutEmptyState: LinearLayout
    private lateinit var adapter: MountainAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_favorit, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViews(view)
        setupRecyclerView()
    }

    private fun initViews(view: View) {
        tvFavoriteCount = view.findViewById(R.id.tvFavoriteCount)
        rvFavorites = view.findViewById(R.id.rvFavorites)
        layoutEmptyState = view.findViewById(R.id.layoutEmptyState)
    }

    private fun setupRecyclerView() {
        adapter = MountainAdapter(
            emptyList(),
            MountainAdapter.LayoutType.HORIZONTAL,

            // ✅ KLIK ITEM → DETAIL GUNUNG
            onItemClick = { mountain ->
                val action =
                    FavoritFragmentDirections
                        .actionFavoritFragmentToMountainDetailFragment(mountain.id)
                findNavController().navigate(action)
            },

            // ❤️ KLIK FAVORITE → TOGGLE
            onFavoriteClick = { mountain ->
                UserSession.toggleFavorite(mountain.id)
                loadFavorites()
            }
        )

        rvFavorites.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@FavoritFragment.adapter
        }
    }

    private fun loadFavorites() {
        val allMountains = MountainsRepository.getMountains()
        val favoriteMountains = allMountains.filter { 
            UserSession.isFavorite(it.id)

        }

        adapter.updateData(favoriteMountains)

        tvFavoriteCount.text = getString(R.string.favorit_count_format, favoriteMountains.size)

        if (favoriteMountains.isEmpty()) {
            rvFavorites.visibility = View.GONE
            layoutEmptyState.visibility = View.VISIBLE
        } else {
            rvFavorites.visibility = View.VISIBLE
            layoutEmptyState.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }
}