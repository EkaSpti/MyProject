package com.pab.zenith.fragment

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.pab.zenith.R
import com.pab.zenith.data.UserSession
import android.widget.Toast


class EditProfileFragment : Fragment(R.layout.fragment_edit_profile) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etName = view.findViewById<EditText>(R.id.etEditName)
        val etLocation = view.findViewById<EditText>(R.id.etEditLocation)
        val btnSave = view.findViewById<Button>(R.id.btnSaveProfile)

        val user = UserSession.getCurrentUser()

        if (user == null) {
            findNavController().navigateUp()
            return
        }

        // Prefill data
        etName.setText(user?.name)
        etLocation.setText(user?.location)

        btnSave.setOnClickListener {
            user?.name = etName.text.toString()
            user?.location = etLocation.text.toString()

            findNavController().navigateUp()
        }

        etLocation.setText(user?.location)

        btnSave.setOnClickListener {
            val newName = etName.text.toString().trim()
            val newLocation = etLocation.text.toString().trim()

            if (newName.isEmpty() || newLocation.isEmpty()) {
                Toast.makeText(requireContext(), "Data tidak boleh kosong", Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }

            user.name = newName
            user.location = newLocation

            findNavController().navigateUp()
        }

    }

}
