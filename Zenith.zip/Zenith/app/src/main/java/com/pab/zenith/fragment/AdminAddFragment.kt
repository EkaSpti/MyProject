package com.pab.zenith.fragment

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.pab.zenith.R
import com.pab.zenith.data.Mountain
import com.pab.zenith.data.MountainsRepository
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import java.util.UUID

class AdminAddFragment : Fragment(R.layout.fragment_admin_add) {

    private lateinit var etMountainName: EditText
    private lateinit var etLocation: EditText
    private lateinit var etHeight: EditText
    private lateinit var etRating: EditText
    private lateinit var etImageUrl: EditText
    private lateinit var etDescription: EditText
    private lateinit var chipGroupDifficulty: ChipGroup
    private lateinit var tvError: TextView
    private lateinit var tvSuccess: TextView
    private lateinit var btnAddMountain: MaterialButton

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 🔗 HUBUNGKAN VIEW DENGAN XML
        etMountainName = view.findViewById(R.id.etMountainName)
        etLocation = view.findViewById(R.id.etLocation)
        etHeight = view.findViewById(R.id.etHeight)
        etRating = view.findViewById(R.id.etRating)
        etImageUrl = view.findViewById(R.id.etImageUrl)
        etDescription = view.findViewById(R.id.etDescription)
        chipGroupDifficulty = view.findViewById(R.id.chipGroupDifficulty)
        tvError = view.findViewById(R.id.tvError)
        tvSuccess = view.findViewById(R.id.tvSuccess)
        btnAddMountain = view.findViewById(R.id.btnAddMountain)

        btnAddMountain.setOnClickListener {
            handleAddMountain()
        }
    }

    private fun handleAddMountain() {
        tvError.visibility = View.GONE
        tvSuccess.visibility = View.GONE

        val name = etMountainName.text.toString().trim()
        val location = etLocation.text.toString().trim()
        val height = etHeight.text.toString().trim()
        val ratingText = etRating.text.toString().trim()
        val imageUrl = etImageUrl.text.toString().trim()
        val description = etDescription.text.toString().trim()

        if (name.isEmpty() || location.isEmpty() || height.isEmpty() ||
            ratingText.isEmpty() || imageUrl.isEmpty() || description.isEmpty()
        ) {
            showError("Semua field wajib diisi")
            return
        }

        val rating = ratingText.toDoubleOrNull()
        if (rating == null || rating !in 1.0..5.0) {
            showError("Rating harus antara 1.0 - 5.0")
            return
        }

        val difficulty = when (chipGroupDifficulty.checkedChipId) {
            R.id.chipMudah -> Mountain.Difficulty.MUDAH
            R.id.chipSedang -> Mountain.Difficulty.SEDANG
            R.id.chipSulit -> Mountain.Difficulty.SULIT
            else -> Mountain.Difficulty.MUDAH
        }

        val mountain = Mountain(
            id = UUID.randomUUID().toString(),
            name = name,
            image = imageUrl,
            rating = rating,
            location = location,
            height = height,
            description = description,
            difficulty = difficulty,
            images = listOf(imageUrl)
        )

        MountainsRepository.addMountain(mountain)

        showSuccess("Gunung berhasil ditambahkan")
        clearForm()
    }

    private fun showError(msg: String) {
        tvError.text = msg
        tvError.visibility = View.VISIBLE
    }

    private fun showSuccess(msg: String) {
        tvSuccess.text = msg
        tvSuccess.visibility = View.VISIBLE
    }

    private fun clearForm() {
        etMountainName.text.clear()
        etLocation.text.clear()
        etHeight.text.clear()
        etRating.text.clear()
        etImageUrl.text.clear()
        etDescription.text.clear()
        chipGroupDifficulty.check(R.id.chipMudah)
    }
}


