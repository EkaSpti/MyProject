package com.pab.zenith.data

data class User(
    var name: String,
    val email: String,
    var location: String = "",
    val isAdmin: Boolean = false
)

object UserSession {
    private var currentUser: User? = null
    private val favorites = mutableSetOf<String>()

    fun login(email: String, password: String): User? {
        return when {
            email.lowercase() == "admin@zenith.com" && password == "admin123" -> {
                User("Admin Zenith", email, isAdmin = true).also { currentUser = it }
            }
            password.length >= 6 -> {
                val userName = email.substringBefore("@").replaceFirstChar { it.uppercase() }
                User(userName, email, isAdmin = false).also { currentUser = it }
            }
            else -> null
        }
    }

    fun register(name: String, email: String, password: String): User? {
        return if (email.lowercase() != "admin@zenith.com" && password.length >= 6) {
            User(name, email, isAdmin = false).also { currentUser = it }
        } else {
            null
        }
    }

    fun getCurrentUser(): User? = currentUser

    fun logout() {
        currentUser = null
        favorites.clear()
    }

    fun toggleFavorite(mountainId: String) {
        if (favorites.contains(mountainId)) {
            favorites.remove(mountainId)
        } else {
            favorites.add(mountainId)
        }
    }

    fun isFavorite(mountainId: String): Boolean = favorites.contains(mountainId)

    fun getFavorites(): Set<String> = favorites.toSet()
}
